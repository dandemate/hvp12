#include <stdio.h>
#include <stdlib.h>

typedef struct ize {
			char B;
			struct ize *NEXT;
		} ELEM;

void push(char C, ELEM **H){
	ELEM *TMP;
	TMP = (ELEM*)malloc(sizeof(ELEM));
	(*TMP).B = C;
	(*TMP).NEXT = *H;
	*H = TMP;
}

char pop(ELEM **H){
	ELEM *TMP = *H;
	*H = (*TMP).NEXT;
	char c = (*TMP).B;
	free(TMP);
	return c;
}

int main(){
	ELEM *fej = NULL;
	char c;

	while (!feof(stdin)){
		scanf("%c", &c);
		push(c, &fej);
	}

	while (fej != NULL){
		printf("%c", pop(&fej));
	}
	return 0;
}