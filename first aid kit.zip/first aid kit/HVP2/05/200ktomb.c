#include <stdio.h>
#include <stdlib.h>


int main(){
	
		int tomb[200000];
		int i;
		for (i = 0; i < 200000; i++){
			tomb[i] = rand()%101; 
			printf("%d\n", tomb[i]);
		}
}