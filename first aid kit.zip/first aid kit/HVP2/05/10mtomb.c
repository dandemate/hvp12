#include <stdio.h>
#include <stdlib.h>


int main(){
	
		int *tomb = (int*)malloc(sizeof(int)*10000000);
		int i;
		for (i = 0; i < 10000000; i++){
			tomb[i] = rand()%101; 
			printf("%d\n", tomb[i]);
		}
		free(tomb);
}