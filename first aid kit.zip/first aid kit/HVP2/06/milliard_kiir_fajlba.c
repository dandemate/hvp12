#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main(){
	int T[100];
	int i;

	int f;
	f = open("out.txt",O_CREAT|O_WRONLY,S_IRUSR|S_IRGRP|S_IROTH);

	for (i = 0; i < 100; i++){
		T[i] = rand()%1000000000;
	}

	write(f, T, 400);

	close(f);


}