#include <stdio.h>

void multifunk(int *T, int N, int *min, int *max, float *avg){
	int i;
	float sum = 0;
	*min = T[0];
	*max = T[0];
	*avg = T[0];
	for (i = 0; i < N; i++){
		if (T[i] < *min)
			*min = T[i];
		if (T[i] > *max)
			*max = T[i];
		sum += T[i];
	}
	*avg = sum/N;
}

int main(){

	int tomb[10] = {-1, 0, 1, 2, 3, 4, 5, 6, 7, 8};
	int min, max;
	float avg;
	multifunk(tomb, 10, &min, &max, &avg);

	printf("Minimum: %d\n", min);
	printf("Maximum: %d\n", max);
	printf("Average: %.3f\n", avg);
	
	return 0;
}