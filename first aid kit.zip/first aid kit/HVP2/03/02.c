#include <stdio.h>

void skalarmulti(int **T, int N, int s){
	int i;
	for (i = 0; i < N; i++){
		T[i] *= s;
		printf("%d\n", T[i]);
	}
}

int main(){
	int tomb[2][3] = {{0,1,2},{3,4,5}};
	skalarmulti(*tomb, 6, 2);
	for (int i = 0; i < 6; i++){
		printf("%d\n", tomb[i]);
	}
}