#include <stdio.h>
#include <stdlib.h>

int main()
{
    int sum = 0;
    int n = 0;
    float avg = 0;
    char* num;
    while(!feof(stdin)){
        fscanf(stdin, &num);
        //printf("%d", atoi(num));
        n++;
        sum += atoi(num);
    }
    avg = sum/n;
    printf("%f", avg);
    printf("VALAMI");
    return 0;
}
