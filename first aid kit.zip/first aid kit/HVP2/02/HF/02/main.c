#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    srand(time(NULL));
    int i = 0;
    for (i; i < 10; i++){
         printf("%d\n", rand()%100+1);
    }
    return 0;
}
