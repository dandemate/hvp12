#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char** argv[])
{
    srand(time(NULL));
    int n = atoi(argv[1]);
    int i = 0;
    for (i; i < n; i++){
         fprintf(stdin, "%d\n", rand()%100+1);
    }
    return 0;
}
