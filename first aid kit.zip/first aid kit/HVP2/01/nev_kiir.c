#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv){
	char* nev = getenv("LOGNAME");
	printf("Hello, %s!\n", nev);
	return 0;
}
