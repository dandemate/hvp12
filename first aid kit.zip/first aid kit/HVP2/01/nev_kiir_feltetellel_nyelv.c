#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv){

//házi: működjön úgy is, hogy pl. "./nevnyelv -hu Tomek"!

	if ((argc == 2) && (strcmp(argv[1],"-hu") == 0)){
			printf("Szia, %s!\n", getenv("LOGNAME"));
			return 0;
		}
	if (argc == 3 && (strcmp(argv[2],"-hu") == 0)){
			printf("Szia, %s!\n", argv[1]);
			return 0;
		}
	if (argc == 1)
		printf("Hello, %s!\n", getenv("LOGNAME"));
	else
		printf("Hello, %s!\n", argv[1]);

	return 0;
}
