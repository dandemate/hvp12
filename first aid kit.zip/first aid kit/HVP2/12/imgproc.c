#include<unistd.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdlib.h>

#define BlockSize 1024

int main(int argc, char *argv[]){
   int in,out;
   char *sor;

   in= open(argv[1],O_RDONLY);
   out=open(argv[2],O_WRONLY|O_CREAT|O_TRUNC,S_IRUSR|S_IWUSR);

   read(in,sor,54);
   write(out,sor,54);

   lseek(in, 18, SEEK_SET);

   int w, h;
   read(in, &w, 4);
   read(in, &h, 4);

   lseek(in, 54, SEEK_SET);

   
   int bytesperrow = 3*w+((3*w%4 == 0)?(0):(4-(3*w%4)));
   sor = (char*)malloc(bytesperrow);

   int i,j,c;

   for(i = 0; i < h; i++){
      read(in,sor,bytesperrow);
      for(j = 0; j < 3*w; j+=3){
         c = ((sor[j]&0xFF)+(sor[j+1]&0xFF)+(sor[j+2]&0xFF))/3;
         sor[j] = (char)c;
         sor[j+1] = (char)c;
         sor[j+2] = (char)c;
      }
      write(out,sor,bytesperrow);
   }

   close(in);
   close(out);

   free(sor);

   return 0;
   }