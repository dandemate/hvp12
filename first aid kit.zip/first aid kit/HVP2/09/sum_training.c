#include<stdio.h>
#include<stdlib.h>
#include<signal.h>
#include<unistd.h>
#include<time.h>

float count = 0;
float all = 0;

void end(int sig){
   printf("\nJó valaszok aranya: %.2f%%\n",(count/all)*100);
   kill(getpid(),SIGKILL);
   }

int main(){
	
   srand(time(NULL));
   signal(SIGALRM,end);
   alarm(10);

   while(1){
   		int a = rand()%20;
   		int b = rand()%20;
   		int s = a + b;
   		int s_t = 0;
   		printf("%d + %d = ?",a,b);
   		scanf("%d",&s_t);
   		if (s_t == s)
   			count++;
   		all++;
   }
   
   
   return 0;
   }
