#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>
#include <sys/stat.h>
#include <string.h>
#include <dirent.h>

static int* T;
static int N;

void foo(int sig){
	;
}

void end(int sig){
	int R = T[0];
	int i;
	for (i = 1; i < N; i++){
		R &= T[i];
	}

	free(T);

	fprintf(stderr, "Felszabadult\n");

	FILE *f;
	f = fopen("results.txt", "a");
	fprintf(f, "%d\n", R);
	fclose(f);

	kill(getpid(), SIGKILL);
}

int main(int argc, char* argv[]){
	signal(SIGALRM, end);
	signal(SIGINT, foo);

	scanf("%d", &N);
	srand(time(NULL));

	alarm(10);

	if (N < 10)
		N = 10;

	T = (int*)malloc(sizeof(int)*N);

	T[0] = argc;
	//printf("Aktualis parancssori argumentumok szama: %d\n", T[0]);

	T[1] = getpid();
	//printf("Process azonositoja: %d\n", T[1]);

	time_t c;
	T[2] = time(&c);
	//printf("Rendszerido masodpercben: %d\n", T[2]);

	int tmp;
	struct stat inode;
	tmp = stat(argv[0],&inode);
	T[3] = (int)inode.st_size;
	//printf("Aktualisan futtatott fajl merete bajtban: %d\n", T[3]);
	
	char* home = getenv("HOME");
	T[4] = 0;
	int i;
	for (i = 0; i < strlen(home); i++){
		if (home[i] == '/')
			T[4]++;
	}
	//printf("HOME-ban a / jelek szama: %d\n", T[4]);

	DIR *d;
	struct dirent *entry;
	d = opendir(".");
	T[5] = 0;
	while((entry = readdir(d)) != NULL){
		if((*entry).d_name[0] == '.')
			T[5]++;
	}
	closedir(d);
	T[5] -= 2;	//a . és a .. is benne van
	//printf("Rejtett objektumok szama a mappaban: %d\n", T[5]);
	
	T[6] = 0b10001000100010001000100010001000;
	//printf("10001000 10001000 10001000 10001000 erteke: %d\n", T[6]);
	
	for (i = 7; i < N; i++){
		T[i] = rand() % (155-35+1) + 35;
	}

	sleep();

	return 0;
}