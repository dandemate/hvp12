#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main(){
	int i=0;
	pid_t pid;
	FILE *f;
   
    for (i = 0; i < 100; i++){
    	pid = fork();
   		if (pid == 0){	//gyerek
   			f = fopen("lista.txt", "a");
   			fprintf(f, "%d\n", i);
   			fclose(f);
   			return 0;
  	 	}
  	 	else{			//szulo
 	  		printf("%d\n", i);
 	  	}
   	}
   	return 0;
}
